'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { authService, RegisterCompanyInput } from '@/lib/auth';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

export default function RegisterPage() {
  const router = useRouter();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  
  const [companyData, setCompanyData] = useState({
    companyName: '',
    registrationNumber: '',
    taxPin: '',
    nssf: '',
    nhif: '',
    address: '',
    phone: '',
    email: '',
  });

  const [adminData, setAdminData] = useState({
    adminFirstName: '',
    adminLastName: '',
    adminEmail: '',
    adminPassword: '',
    confirmPassword: '',
  });

  const handleCompanyChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setCompanyData({
      ...companyData,
      [e.target.name]: e.target.value,
    });
  };

  const handleAdminChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setAdminData({
      ...adminData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    // Validate passwords match
    if (adminData.adminPassword !== adminData.confirmPassword) {
      setError('Passwords do not match');
      return;
    }

    // Validate password strength
    if (!authService.constructor.isStrongPassword(adminData.adminPassword)) {
      setError('Password must be at least 8 characters with uppercase, lowercase, and numbers');
      return;
    }

    setIsLoading(true);

    try {
      const input: RegisterCompanyInput = {
        ...companyData,
        adminFirstName: adminData.adminFirstName,
        adminLastName: adminData.adminLastName,
        adminEmail: adminData.adminEmail,
        adminPassword: adminData.adminPassword,
      };

      const { sessionToken } = authService.registerCompany(input);

      // Store session token
      localStorage.setItem('sessionToken', sessionToken);

      // Redirect to dashboard
      router.push('/dashboard');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Registration failed');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-2xl">
        {/* Header */}
        <div className="text-center mb-10">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-xl bg-primary text-primary-foreground mb-6 shadow-lg">
            <span className="text-2xl font-bold">PK</span>
          </div>
          <h1 className="text-4xl font-bold text-foreground">PayrollKE</h1>
          <p className="text-muted-foreground mt-2 text-sm">Register Your Company</p>
        </div>

        {/* Registration Card */}
        <Card className="shadow-xl border-border">
          <CardHeader className="pb-5">
            <CardTitle className="text-2xl">Set Up Your Company</CardTitle>
            <CardDescription className="text-sm">Enter your company and administrator details to get started</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              {error && (
                <Alert variant="destructive">
                  <AlertDescription className="text-sm">{error}</AlertDescription>
                </Alert>
              )}

              <Tabs defaultValue="company" className="w-full">
                <TabsList className="grid w-full grid-cols-2 bg-muted">
                  <TabsTrigger value="company" className="text-sm">Company</TabsTrigger>
                  <TabsTrigger value="admin" className="text-sm">Administrator</TabsTrigger>
                </TabsList>

                <TabsContent value="company" className="space-y-4 pt-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="col-span-2 space-y-2">
                      <Label htmlFor="companyName" className="text-sm font-medium">Company Name</Label>
                      <Input
                        id="companyName"
                        name="companyName"
                        placeholder="TechCorp Kenya Ltd"
                        value={companyData.companyName}
                        onChange={handleCompanyChange}
                        className="border-border bg-input"
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="registrationNumber" className="text-sm font-medium">Registration Number</Label>
                      <Input
                        id="registrationNumber"
                        name="registrationNumber"
                        placeholder="PVT/REG/2024/123456"
                        value={companyData.registrationNumber}
                        onChange={handleCompanyChange}
                        className="border-border bg-input"
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="taxPin" className="text-sm font-medium">Tax PIN</Label>
                      <Input
                        id="taxPin"
                        name="taxPin"
                        placeholder="A000000000X"
                        value={companyData.taxPin}
                        onChange={handleCompanyChange}
                        className="border-border bg-input"
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="nssf" className="text-sm font-medium">NSSF Number</Label>
                      <Input
                        id="nssf"
                        name="nssf"
                        placeholder="NSSF/2024/123456"
                        value={companyData.nssf}
                        onChange={handleCompanyChange}
                        className="border-border bg-input"
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="nhif" className="text-sm font-medium">NHIF Number</Label>
                      <Input
                        id="nhif"
                        name="nhif"
                        placeholder="NHIF/2024/123456"
                        value={companyData.nhif}
                        onChange={handleCompanyChange}
                        className="border-border bg-input"
                        required
                      />
                    </div>

                    <div className="col-span-2 space-y-2">
                      <Label htmlFor="address" className="text-sm font-medium">Address</Label>
                      <Input
                        id="address"
                        name="address"
                        placeholder="123 Business Park, Nairobi"
                        value={companyData.address}
                        onChange={handleCompanyChange}
                        className="border-border bg-input"
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="phone" className="text-sm font-medium">Phone Number</Label>
                      <Input
                        id="phone"
                        name="phone"
                        placeholder="+254712345678"
                        value={companyData.phone}
                        onChange={handleCompanyChange}
                        className="border-border bg-input"
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="email" className="text-sm font-medium">Company Email</Label>
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        placeholder="hr@company.com"
                        value={companyData.email}
                        onChange={handleCompanyChange}
                        className="border-border bg-input"
                        required
                      />
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="admin" className="space-y-4 pt-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="adminFirstName" className="text-sm font-medium">First Name</Label>
                      <Input
                        id="adminFirstName"
                        name="adminFirstName"
                        placeholder="John"
                        value={adminData.adminFirstName}
                        onChange={handleAdminChange}
                        className="border-border bg-input"
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="adminLastName" className="text-sm font-medium">Last Name</Label>
                      <Input
                        id="adminLastName"
                        name="adminLastName"
                        placeholder="Doe"
                        value={adminData.adminLastName}
                        onChange={handleAdminChange}
                        className="border-border bg-input"
                        required
                      />
                    </div>

                    <div className="col-span-2 space-y-2">
                      <Label htmlFor="adminEmail" className="text-sm font-medium">Email Address</Label>
                      <Input
                        id="adminEmail"
                        name="adminEmail"
                        type="email"
                        placeholder="admin@company.com"
                        value={adminData.adminEmail}
                        onChange={handleAdminChange}
                        className="border-border bg-input"
                        required
                      />
                    </div>

                    <div className="col-span-2 space-y-2">
                      <Label htmlFor="adminPassword" className="text-sm font-medium">Password</Label>
                      <Input
                        id="adminPassword"
                        name="adminPassword"
                        type="password"
                        placeholder="••••••••"
                        value={adminData.adminPassword}
                        onChange={handleAdminChange}
                        className="border-border bg-input"
                        required
                      />
                      <p className="text-xs text-muted-foreground">
                        At least 8 characters, includes uppercase, lowercase, and numbers
                      </p>
                    </div>

                    <div className="col-span-2 space-y-2">
                      <Label htmlFor="confirmPassword" className="text-sm font-medium">Confirm Password</Label>
                      <Input
                        id="confirmPassword"
                        name="confirmPassword"
                        type="password"
                        placeholder="••••••••"
                        value={adminData.confirmPassword}
                        onChange={handleAdminChange}
                        className="border-border bg-input"
                        required
                      />
                    </div>
                  </div>
                </TabsContent>
              </Tabs>

              <Button 
                type="submit" 
                className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-medium"
                disabled={isLoading}
              >
                {isLoading ? 'Setting up...' : 'Create Account'}
              </Button>
            </form>

            <div className="mt-6 pt-6 border-t border-border">
              <p className="text-center text-sm text-muted-foreground">
                Already have an account?{' '}
                <Link href="/" className="text-primary hover:text-primary/90 font-semibold">
                  Sign in
                </Link>
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
