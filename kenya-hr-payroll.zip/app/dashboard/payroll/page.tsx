'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { authService, AuthSession } from '@/lib/auth';
import { db, Payroll, PayrollDetail } from '@/lib/db-schema';
import {
  calculatePayroll,
  calculateBulkPayroll,
  generatePayrollSummary,
  PayrollCalculationResult,
  PayrollSummary,
} from '@/lib/payroll-calculator';
import {
  getCurrentMonth,
  getPreviousMonth,
  getNextMonth,
  getMonthName,
  formatCurrency,
  generateId,
  getStatusDisplayName,
  getStatusColor,
} from '@/lib/utils-hr';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';

export default function PayrollPage() {
  const [session, setSession] = useState<AuthSession | null>(null);
  const [selectedMonth, setSelectedMonth] = useState(getCurrentMonth());
  const [payroll, setPayroll] = useState<Payroll | null>(null);
  const [payrollDetails, setPayrollDetails] = useState<PayrollDetail[]>([]);
  const [summary, setSummary] = useState<PayrollSummary | null>(null);
  const [isCreating, setIsCreating] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  useEffect(() => {
    const token = localStorage.getItem('sessionToken');
    if (token) {
      const sess = authService.getSession(token);
      setSession(sess);
      if (sess) {
        loadPayroll(sess.companyId, selectedMonth);
      }
    }
  }, [selectedMonth]);

  const loadPayroll = (companyId: string, month: string) => {
    const existingPayroll = db.getPayrollByMonth(companyId, month);
    setPayroll(existingPayroll || null);

    if (existingPayroll) {
      const details = db.getPayrollDetailsByPayroll(existingPayroll.id);
      setPayrollDetails(details);

      const calculations = new Map<string, PayrollCalculationResult>();
      details.forEach(d => {
        calculations.set(d.employeeId, {
          basicSalary: d.basicSalary,
          allowances: { total: d.allowancesTotal, breakdown: d.allowanceBreakdown },
          grossSalary: d.grossPay,
          deductions: {
            nssf: d.nssfAmount,
            nhif: d.nhifAmount,
            incomeTax: d.incomeTaxAmount,
            other: { total: d.otherDeductionsTotal, breakdown: d.otherDeductionsBreakdown },
            total: d.totalDeductions,
          },
          netPay: d.netPay,
          taxableIncome: 0,
          personalRelief: 0,
          insuranceRelief: 0,
        });
      });
      setSummary(generatePayrollSummary(calculations));
    } else {
      setPayrollDetails([]);
      setSummary(null);
    }
  };

  const handleCreatePayroll = async () => {
    if (!session) return;
    setError('');

    try {
      // Check if payroll already exists
      if (payroll) {
        setError('Payroll for this month already exists');
        return;
      }

      // Get active employees
      const employees = db.getActiveEmployeesByCompany(session.companyId);

      if (employees.length === 0) {
        setError('No active employees to process payroll');
        return;
      }

      // Calculate payroll for all employees
      const calculations = calculateBulkPayroll(employees);

      // Create payroll record
      const newPayroll: Payroll = {
        id: generateId('payroll'),
        companyId: session.companyId,
        payrollMonth: selectedMonth,
        payrollCycle: 'monthly',
        status: 'draft',
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      db.createPayroll(newPayroll);

      // Create payroll details for each employee
      const details: PayrollDetail[] = [];
      calculations.forEach((calc, employeeId) => {
        const detail: PayrollDetail = {
          id: generateId('detail'),
          payrollId: newPayroll.id,
          employeeId,
          companyId: session.companyId,
          basicSalary: calc.basicSalary,
          allowancesTotal: calc.allowances.total,
          allowanceBreakdown: calc.allowances.breakdown,
          grossPay: calc.grossSalary,
          nssfAmount: calc.deductions.nssf,
          nhifAmount: calc.deductions.nhif,
          incomeTaxAmount: calc.deductions.incomeTax,
          otherDeductionsTotal: calc.deductions.other.total,
          otherDeductionsBreakdown: calc.deductions.other.breakdown,
          totalDeductions: calc.deductions.total,
          netPay: calc.netPay,
          paymentStatus: 'pending',
          paymentMethod: 'bank_transfer',
          createdAt: new Date(),
          updatedAt: new Date(),
        };

        db.createPayrollDetail(detail);
        details.push(detail);
      });

      setPayroll(newPayroll);
      setPayrollDetails(details);
      setSummary(generatePayrollSummary(calculations));
      setSuccess('Payroll created successfully');
      setIsCreating(false);
      setTimeout(() => setSuccess(''), 3000);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to create payroll');
    }
  };

  const handleSubmitPayroll = () => {
    if (!payroll) return;
    const updated = db.updatePayroll(payroll.id, { status: 'pending_approval' });
    if (updated) {
      setPayroll(updated);
      setSuccess('Payroll submitted for approval');
      setTimeout(() => setSuccess(''), 3000);
    }
  };

  const handleApprovePayroll = () => {
    if (!payroll || !session) return;
    const updated = db.updatePayroll(payroll.id, {
      status: 'approved',
      approvedAt: new Date(),
      approvedBy: session.userId,
    });
    if (updated) {
      setPayroll(updated);
      setSuccess('Payroll approved');
      setTimeout(() => setSuccess(''), 3000);
    }
  };

  const handleProcessPayroll = () => {
    if (!payroll || !session) return;
    const updated = db.updatePayroll(payroll.id, {
      status: 'processed',
      processedAt: new Date(),
      processedBy: session.userId,
    });
    if (updated) {
      setPayroll(updated);
      setSuccess('Payroll processed and ready for payment');
      setTimeout(() => setSuccess(''), 3000);
    }
  };

  if (!session) return null;

  const isLocked = payroll && ['processed', 'paid'].includes(payroll.status);
  const canEdit = !payroll || payroll.status === 'draft';

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-foreground">Payroll Management</h1>
        <p className="text-muted-foreground mt-1 text-sm">Create, review, and process monthly payroll for your team</p>
      </div>

      {error && (
        <div className="bg-destructive/10 border border-destructive text-destructive rounded-lg p-3 text-sm">
          {error}
        </div>
      )}

      {success && (
        <div className="bg-green-500/10 border border-green-500 text-green-600 rounded-lg p-3 text-sm">
          {success}
        </div>
      )}

      {/* Month Selection */}
      <Card className="border-border">
        <CardHeader className="pb-4">
          <CardTitle className="text-lg">Select Payroll Month</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4">
            <Button
              variant="outline"
              className="border-border"
              onClick={() => setSelectedMonth(getPreviousMonth(selectedMonth))}
            >
              Previous
            </Button>
            <div className="text-center flex-1">
              <p className="text-lg font-medium">{getMonthName(selectedMonth)}</p>
            </div>
            <Button
              variant="outline"
              onClick={() => setSelectedMonth(getNextMonth(selectedMonth))}
            >
              Next
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Payroll Status */}
      {payroll && (
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>Payroll Status</CardTitle>
            <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(payroll.status)}`}>
              {getStatusDisplayName(payroll.status)}
            </span>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {payroll.status === 'draft' && (
                <>
                  <p className="text-sm text-gray-600">Review the payroll details before submitting</p>
                  <Button onClick={handleSubmitPayroll}>Submit for Approval</Button>
                </>
              )}
              {payroll.status === 'pending_approval' && (
                <>
                  <p className="text-sm text-gray-600">Waiting for approval</p>
                  {session.userRole === 'admin' && (
                    <Button onClick={handleApprovePayroll}>Approve Payroll</Button>
                  )}
                </>
              )}
              {payroll.status === 'approved' && (
                <>
                  <p className="text-sm text-gray-600">Ready to process payments</p>
                  {session.userRole === 'admin' && (
                    <Button onClick={handleProcessPayroll}>Process Payroll</Button>
                  )}
                </>
              )}
              {payroll.status === 'processed' && (
                <p className="text-sm text-green-600">Payroll processed. Ready for bank transfer.</p>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Payroll Summary */}
      {summary && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-gray-600">Total Employees</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">{summary.totalEmployees}</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-gray-600">Total Gross Salaries</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">{formatCurrency(summary.totalGrossSalaries)}</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-gray-600">Total Deductions</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">{formatCurrency(summary.totalDeductions)}</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-gray-600">Total NSSF</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">{formatCurrency(summary.totalNSSF)}</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-gray-600">Total NHIF</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">{formatCurrency(summary.totalNHIF)}</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-gray-600">Total Net Pay</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold text-green-600">{formatCurrency(summary.totalNetPay)}</p>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Payroll Details */}
      {payroll ? (
        <Card>
          <CardHeader>
            <CardTitle>Payroll Details</CardTitle>
          </CardHeader>
          <CardContent>
            {payrollDetails.length === 0 ? (
              <p className="text-center py-12 text-gray-600">No payroll details available</p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-gray-200">
                      <th className="text-left py-3 px-4 font-medium text-gray-900">Employee</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-900">Basic Salary</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-900">Allowances</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-900">Gross Pay</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-900">NSSF</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-900">NHIF</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-900">Tax</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-900">Deductions</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-900">Net Pay</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-900">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {payrollDetails.map((detail) => {
                      const employee = db.getEmployee(detail.employeeId);
                      return (
                        <tr key={detail.id} className="border-b border-gray-100 hover:bg-gray-50">
                          <td className="py-3 px-4">
                            <Link
                              href={`/dashboard/employees/${detail.employeeId}`}
                              className="text-blue-600 hover:text-blue-700"
                            >
                              {employee?.firstName} {employee?.lastName}
                            </Link>
                          </td>
                          <td className="py-3 px-4">{formatCurrency(detail.basicSalary)}</td>
                          <td className="py-3 px-4">{formatCurrency(detail.allowancesTotal)}</td>
                          <td className="py-3 px-4 font-medium">{formatCurrency(detail.grossPay)}</td>
                          <td className="py-3 px-4">{formatCurrency(detail.nssfAmount)}</td>
                          <td className="py-3 px-4">{formatCurrency(detail.nhifAmount)}</td>
                          <td className="py-3 px-4">{formatCurrency(detail.incomeTaxAmount)}</td>
                          <td className="py-3 px-4">{formatCurrency(detail.totalDeductions)}</td>
                          <td className="py-3 px-4 font-medium text-green-600">{formatCurrency(detail.netPay)}</td>
                          <td className="py-3 px-4">
                            <Link href={`/dashboard/payroll/${detail.id}/payslip`}>
                              <Button size="sm" variant="outline">
                                View
                              </Button>
                            </Link>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      ) : (
        <Dialog open={isCreating} onOpenChange={setIsCreating}>
          <Card>
            <CardHeader>
              <CardTitle>No Payroll Data</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-4">Create payroll for {getMonthName(selectedMonth)}</p>
              <DialogTrigger asChild>
                <Button>Create Payroll</Button>
              </DialogTrigger>
            </CardContent>
          </Card>

          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create Payroll</DialogTitle>
              <DialogDescription>
                This will generate payroll for all active employees in {getMonthName(selectedMonth)}
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <Alert>
                <AlertDescription>
                  This action will calculate deductions based on current employee records and 2024 Kenya tax rates.
                </AlertDescription>
              </Alert>
              <div className="flex gap-3 justify-end">
                <Button variant="outline" onClick={() => setIsCreating(false)}>
                  Cancel
                </Button>
                <Button onClick={handleCreatePayroll}>Create Payroll</Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
