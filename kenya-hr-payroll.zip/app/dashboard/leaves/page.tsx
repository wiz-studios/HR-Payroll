'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { authService, AuthSession } from '@/lib/auth';
import { db, Employee } from '@/lib/db-schema';
import { formatCurrency, formatDate } from '@/lib/utils-hr';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { DataTable } from '@/components/data-table';

interface Leave {
  id: string;
  employeeId: string;
  employeeName: string;
  leaveType: string;
  startDate: string;
  endDate: string;
  days: number;
  status: 'pending' | 'approved' | 'rejected';
  reason: string;
  approvedBy?: string;
  approvedDate?: string;
}

export default function LeavesPage() {
  const [session, setSession] = useState<AuthSession | null>(null);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [leaves, setLeaves] = useState<Leave[]>([]);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const [formData, setFormData] = useState({
    employeeId: '',
    leaveType: 'annual',
    startDate: '',
    endDate: '',
    reason: '',
  });

  useEffect(() => {
    const token = localStorage.getItem('sessionToken');
    if (token) {
      const sess = authService.getSession(token);
      setSession(sess);
      if (sess) {
        const emps = db.getEmployeesByCompany(sess.companyId);
        setEmployees(emps);
        // Mock leave data
        setLeaves([
          {
            id: 'leave_1',
            employeeId: emps[0]?.id || '',
            employeeName: emps[0] ? `${emps[0].firstName} ${emps[0].lastName}` : 'N/A',
            leaveType: 'Annual',
            startDate: '2024-02-15',
            endDate: '2024-02-20',
            days: 6,
            status: 'approved',
            reason: 'Holiday',
            approvedBy: 'John Manager',
            approvedDate: '2024-02-10',
          },
        ]);
      }
    }
  }, []);

  const handleSubmitLeave = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    if (!session || !formData.employeeId) {
      setError('Please select an employee');
      return;
    }

    const newLeave: Leave = {
      id: `leave_${Date.now()}`,
      employeeId: formData.employeeId,
      employeeName:
        employees.find((e) => e.id === formData.employeeId)?.firstName +
        ' ' +
        employees.find((e) => e.id === formData.employeeId)?.lastName,
      leaveType: formData.leaveType,
      startDate: formData.startDate,
      endDate: formData.endDate,
      days: Math.ceil(
        (new Date(formData.endDate).getTime() - new Date(formData.startDate).getTime()) / (1000 * 60 * 60 * 24)
      ),
      status: 'pending',
      reason: formData.reason,
    };

    setLeaves([...leaves, newLeave]);
    setFormData({ employeeId: '', leaveType: 'annual', startDate: '', endDate: '', reason: '' });
    setSuccess('Leave request submitted successfully');
    setTimeout(() => setSuccess(''), 3000);
  };

  const handleApproveLeave = (leaveId: string) => {
    setLeaves(
      leaves.map((l) =>
        l.id === leaveId
          ? {
              ...l,
              status: 'approved' as const,
              approvedBy: session?.userName,
              approvedDate: new Date().toISOString().split('T')[0],
            }
          : l
      )
    );
    setSuccess('Leave approved');
    setTimeout(() => setSuccess(''), 3000);
  };

  const pendingLeaves = leaves.filter((l) => l.status === 'pending');
  const approvedLeaves = leaves.filter((l) => l.status === 'approved');

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Leave Management</h1>
        <p className="text-muted-foreground mt-1 text-sm">Request, approve, and track employee leave</p>
      </div>

      {error && (
        <div className="bg-destructive/10 border border-destructive text-destructive rounded-lg p-3 text-sm">
          {error}
        </div>
      )}
      {success && (
        <div className="bg-green-500/10 border border-green-500 text-green-600 rounded-lg p-3 text-sm">
          {success}
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        <Card className="border-border">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-semibold text-muted-foreground uppercase">Pending Requests</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold text-foreground">{pendingLeaves.length}</p>
          </CardContent>
        </Card>
        <Card className="border-border">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-semibold text-muted-foreground uppercase">Approved This Month</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold text-accent">
              {approvedLeaves.filter((l) => new Date(l.approvedDate || '').getMonth() === new Date().getMonth()).length}
            </p>
          </CardContent>
        </Card>
        <Card className="border-border">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-semibold text-muted-foreground uppercase">Total Days Used</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold text-foreground">{approvedLeaves.reduce((sum, l) => sum + l.days, 0)}</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="pending" className="w-full">
        <TabsList className="grid w-full grid-cols-2 bg-muted">
          <TabsTrigger value="pending" className="text-sm">
            Pending ({pendingLeaves.length})
          </TabsTrigger>
          <TabsTrigger value="approved" className="text-sm">
            Approved ({approvedLeaves.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="pending" className="space-y-4 pt-4">
          {pendingLeaves.length === 0 ? (
            <Card className="border-border">
              <CardContent className="text-center py-8">
                <p className="text-muted-foreground">No pending leave requests</p>
              </CardContent>
            </Card>
          ) : (
            <div className="border border-border rounded-lg overflow-hidden">
              <table className="w-full">
                <thead>
                  <tr className="bg-muted border-b border-border">
                    <th className="px-4 py-3 text-left text-sm font-semibold text-foreground">Employee</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-foreground">Leave Type</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-foreground">Duration</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-foreground">Days</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-foreground">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {pendingLeaves.map((leave) => (
                    <tr key={leave.id} className="border-b border-border hover:bg-muted/50">
                      <td className="px-4 py-3 text-sm font-medium text-foreground">{leave.employeeName}</td>
                      <td className="px-4 py-3 text-sm text-foreground">{leave.leaveType}</td>
                      <td className="px-4 py-3 text-sm text-muted-foreground">
                        {leave.startDate} to {leave.endDate}
                      </td>
                      <td className="px-4 py-3 text-sm text-foreground font-medium">{leave.days}</td>
                      <td className="px-4 py-3 text-sm">
                        <Button size="sm" onClick={() => handleApproveLeave(leave.id)}>
                          Approve
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </TabsContent>

        <TabsContent value="approved" className="space-y-4 pt-4">
          {approvedLeaves.length === 0 ? (
            <Card className="border-border">
              <CardContent className="text-center py-8">
                <p className="text-muted-foreground">No approved leave requests</p>
              </CardContent>
            </Card>
          ) : (
            <div className="border border-border rounded-lg overflow-hidden">
              <table className="w-full">
                <thead>
                  <tr className="bg-muted border-b border-border">
                    <th className="px-4 py-3 text-left text-sm font-semibold text-foreground">Employee</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-foreground">Leave Type</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-foreground">Duration</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-foreground">Approved By</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-foreground">Date</th>
                  </tr>
                </thead>
                <tbody>
                  {approvedLeaves.map((leave) => (
                    <tr key={leave.id} className="border-b border-border hover:bg-muted/50">
                      <td className="px-4 py-3 text-sm font-medium text-foreground">{leave.employeeName}</td>
                      <td className="px-4 py-3 text-sm text-foreground">{leave.leaveType}</td>
                      <td className="px-4 py-3 text-sm text-muted-foreground">
                        {leave.startDate} to {leave.endDate}
                      </td>
                      <td className="px-4 py-3 text-sm text-foreground">{leave.approvedBy}</td>
                      <td className="px-4 py-3 text-sm text-muted-foreground">{leave.approvedDate}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </TabsContent>
      </Tabs>

      <Card className="border-border">
        <CardHeader>
          <CardTitle>Request New Leave</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmitLeave} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="employeeId" className="text-sm font-medium">
                  Employee
                </Label>
                <select
                  id="employeeId"
                  name="employeeId"
                  value={formData.employeeId}
                  onChange={(e) => setFormData({ ...formData, employeeId: e.target.value })}
                  className="w-full px-3 py-2 border border-border rounded-lg bg-input text-sm"
                >
                  <option value="">Select employee</option>
                  {employees.map((emp) => (
                    <option key={emp.id} value={emp.id}>
                      {emp.firstName} {emp.lastName}
                    </option>
                  ))}
                </select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="leaveType" className="text-sm font-medium">
                  Leave Type
                </Label>
                <select
                  id="leaveType"
                  name="leaveType"
                  value={formData.leaveType}
                  onChange={(e) => setFormData({ ...formData, leaveType: e.target.value })}
                  className="w-full px-3 py-2 border border-border rounded-lg bg-input text-sm"
                >
                  <option value="annual">Annual</option>
                  <option value="sick">Sick</option>
                  <option value="maternity">Maternity</option>
                  <option value="unpaid">Unpaid</option>
                </select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="startDate" className="text-sm font-medium">
                  Start Date
                </Label>
                <Input
                  id="startDate"
                  type="date"
                  value={formData.startDate}
                  onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
                  className="border-border bg-input"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="endDate" className="text-sm font-medium">
                  End Date
                </Label>
                <Input
                  id="endDate"
                  type="date"
                  value={formData.endDate}
                  onChange={(e) => setFormData({ ...formData, endDate: e.target.value })}
                  className="border-border bg-input"
                  required
                />
              </div>

              <div className="col-span-2 space-y-2">
                <Label htmlFor="reason" className="text-sm font-medium">
                  Reason
                </Label>
                <Input
                  id="reason"
                  placeholder="Enter reason for leave"
                  value={formData.reason}
                  onChange={(e) => setFormData({ ...formData, reason: e.target.value })}
                  className="border-border bg-input"
                />
              </div>
            </div>

            <Button type="submit" className="bg-primary hover:bg-primary/90 text-primary-foreground font-medium">
              Submit Leave Request
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
