'use client';

import { useEffect, useState } from 'react';
import { authService, AuthSession } from '@/lib/auth';
import { db } from '@/lib/db-schema';
import { formatCurrency, getMonthName, generateId } from '@/lib/utils-hr';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

interface PayrollReport {
  month: string;
  totalEmployees: number;
  totalGross: number;
  totalNSSF: number;
  totalNHIF: number;
  totalTax: number;
  totalDeductions: number;
  totalNetPay: number;
}

interface TaxReport {
  month: string;
  totalGrossIncome: number;
  totalTaxableIncome: number;
  totalTaxCollected: number;
  totalPersonalRelief: number;
  averageTaxPerEmployee: number;
}

export default function ReportsPage() {
  const [session, setSession] = useState<AuthSession | null>(null);
  const [payrollReports, setPayrollReports] = useState<PayrollReport[]>([]);
  const [taxReports, setTaxReports] = useState<TaxReport[]>([]);
  const [selectedMonth, setSelectedMonth] = useState('');

  useEffect(() => {
    const token = localStorage.getItem('sessionToken');
    if (token) {
      const sess = authService.getSession(token);
      setSession(sess);
      if (sess) {
        loadReports(sess.companyId);
      }
    }
  }, []);

  const loadReports = (companyId: string) => {
    const payrolls = db.getPayrollsByCompany(companyId);

    const reports: PayrollReport[] = payrolls
      .filter(p => p.status !== 'draft')
      .map(p => {
        const details = db.getPayrollDetailsByPayroll(p.id);
        return {
          month: p.payrollMonth,
          totalEmployees: details.length,
          totalGross: details.reduce((sum, d) => sum + d.grossPay, 0),
          totalNSSF: details.reduce((sum, d) => sum + d.nssfAmount, 0),
          totalNHIF: details.reduce((sum, d) => sum + d.nhifAmount, 0),
          totalTax: details.reduce((sum, d) => sum + d.incomeTaxAmount, 0),
          totalDeductions: details.reduce((sum, d) => sum + d.totalDeductions, 0),
          totalNetPay: details.reduce((sum, d) => sum + d.netPay, 0),
        };
      })
      .sort((a, b) => b.month.localeCompare(a.month));

    setPayrollReports(reports);

    const taxReports: TaxReport[] = reports.map(r => ({
      month: r.month,
      totalGrossIncome: r.totalGross,
      totalTaxableIncome: r.totalGross - r.totalNSSF - r.totalNHIF,
      totalTaxCollected: r.totalTax,
      totalPersonalRelief: r.totalEmployees * 2400,
      averageTaxPerEmployee: r.totalEmployees > 0 ? r.totalTax / r.totalEmployees : 0,
    }));

    setTaxReports(taxReports);
  };

  const exportToCSV = (data: any[], filename: string) => {
    const headers = Object.keys(data[0] || {});
    const csv = [
      headers.join(','),
      ...data.map(row => headers.map(h => `"${row[h]}"`).join(',')),
    ].join('\n');

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
  };

  const generateKRAReport = () => {
    const quarter = Math.ceil((new Date().getMonth() + 1) / 3);
    const year = new Date().getFullYear();

    const kraData = taxReports.map(r => ({
      month: r.month,
      'Employee Count': payrollReports.find(p => p.month === r.month)?.totalEmployees || 0,
      'Gross Income': r.totalGrossIncome,
      'Tax Collected': r.totalTaxCollected,
      'NSSF Deducted': payrollReports.find(p => p.month === r.month)?.totalNSSF || 0,
    }));

    exportToCSV(kraData, `KRA_P9_Q${quarter}_${year}.csv`);
  };

  const generateNSSFReport = () => {
    const nssfData = payrollReports.map(r => ({
      month: r.month,
      'Employee Count': r.totalEmployees,
      'NSSF Deducted': r.totalNSSF,
      'Company Contribution': r.totalNSSF * (5.5 / 6), // Approx employer contribution
    }));

    exportToCSV(nssfData, 'NSSF_Report.csv');
  };

  const generateNHIFReport = () => {
    const nhifData = payrollReports.map(r => ({
      month: r.month,
      'Employee Count': r.totalEmployees,
      'NHIF Deducted': r.totalNHIF,
    }));

    exportToCSV(nhifData, 'NHIF_Report.csv');
  };

  if (!session) return null;

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Reports & Analytics</h1>
        <p className="text-muted-foreground mt-1 text-sm">Generate and export payroll reports for compliance and analysis</p>
      </div>

      {/* Tabs */}
      <Tabs defaultValue="payroll" className="w-full">
        <TabsList className="grid w-full grid-cols-3 bg-muted">
          <TabsTrigger value="payroll" className="text-sm">Payroll Summary</TabsTrigger>
          <TabsTrigger value="tax" className="text-sm">Tax Compliance</TabsTrigger>
          <TabsTrigger value="export" className="text-sm">Export Reports</TabsTrigger>
        </TabsList>

        {/* Payroll Report */}
        <TabsContent value="payroll" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Payroll Summary by Month</CardTitle>
            </CardHeader>
            <CardContent>
              {payrollReports.length === 0 ? (
                <p className="text-center py-12 text-gray-600">No processed payrolls available</p>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-gray-200">
                        <th className="text-left py-3 px-4 font-medium text-gray-900">Month</th>
                        <th className="text-left py-3 px-4 font-medium text-gray-900">Employees</th>
                        <th className="text-left py-3 px-4 font-medium text-gray-900">Gross Salaries</th>
                        <th className="text-left py-3 px-4 font-medium text-gray-900">NSSF</th>
                        <th className="text-left py-3 px-4 font-medium text-gray-900">NHIF</th>
                        <th className="text-left py-3 px-4 font-medium text-gray-900">Income Tax</th>
                        <th className="text-left py-3 px-4 font-medium text-gray-900">Total Deductions</th>
                        <th className="text-left py-3 px-4 font-medium text-gray-900">Net Pay</th>
                      </tr>
                    </thead>
                    <tbody>
                      {payrollReports.map((report) => (
                        <tr key={report.month} className="border-b border-gray-100 hover:bg-gray-50">
                          <td className="py-3 px-4 font-medium">{getMonthName(report.month)}</td>
                          <td className="py-3 px-4">{report.totalEmployees}</td>
                          <td className="py-3 px-4">{formatCurrency(report.totalGross)}</td>
                          <td className="py-3 px-4">{formatCurrency(report.totalNSSF)}</td>
                          <td className="py-3 px-4">{formatCurrency(report.totalNHIF)}</td>
                          <td className="py-3 px-4">{formatCurrency(report.totalTax)}</td>
                          <td className="py-3 px-4">{formatCurrency(report.totalDeductions)}</td>
                          <td className="py-3 px-4 text-green-600 font-medium">
                            {formatCurrency(report.totalNetPay)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Summary Cards */}
          {payrollReports.length > 0 && (
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-gray-600">Total Payrolls</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold">{payrollReports.length}</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-gray-600">Total Gross</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold">
                    {formatCurrency(payrollReports.reduce((sum, r) => sum + r.totalGross, 0))}
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-gray-600">Total Tax Paid</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold">
                    {formatCurrency(payrollReports.reduce((sum, r) => sum + r.totalTax, 0))}
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-gray-600">Total Net Paid</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold text-green-600">
                    {formatCurrency(payrollReports.reduce((sum, r) => sum + r.totalNetPay, 0))}
                  </p>
                </CardContent>
              </Card>
            </div>
          )}
        </TabsContent>

        {/* Tax Report */}
        <TabsContent value="tax" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Income Tax Analysis</CardTitle>
            </CardHeader>
            <CardContent>
              {taxReports.length === 0 ? (
                <p className="text-center py-12 text-gray-600">No tax data available</p>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-gray-200">
                        <th className="text-left py-3 px-4 font-medium text-gray-900">Month</th>
                        <th className="text-left py-3 px-4 font-medium text-gray-900">Gross Income</th>
                        <th className="text-left py-3 px-4 font-medium text-gray-900">Taxable Income</th>
                        <th className="text-left py-3 px-4 font-medium text-gray-900">Tax Collected</th>
                        <th className="text-left py-3 px-4 font-medium text-gray-900">Personal Relief</th>
                        <th className="text-left py-3 px-4 font-medium text-gray-900">Avg Tax/Employee</th>
                      </tr>
                    </thead>
                    <tbody>
                      {taxReports.map((report) => (
                        <tr key={report.month} className="border-b border-gray-100 hover:bg-gray-50">
                          <td className="py-3 px-4 font-medium">{getMonthName(report.month)}</td>
                          <td className="py-3 px-4">{formatCurrency(report.totalGrossIncome)}</td>
                          <td className="py-3 px-4">{formatCurrency(report.totalTaxableIncome)}</td>
                          <td className="py-3 px-4 font-medium">{formatCurrency(report.totalTaxCollected)}</td>
                          <td className="py-3 px-4">{formatCurrency(report.totalPersonalRelief)}</td>
                          <td className="py-3 px-4">{formatCurrency(report.averageTaxPerEmployee)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Compliance Exports */}
        <TabsContent value="exports" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Generate Compliance Reports</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card className="bg-blue-50 border border-blue-200">
                  <CardHeader>
                    <CardTitle className="text-lg">KRA P9 Report</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-600 mb-4">
                      Personal Income Tax (PAYE) details for KRA filing
                    </p>
                    <Button onClick={generateKRAReport} className="w-full">
                      Download KRA P9
                    </Button>
                  </CardContent>
                </Card>

                <Card className="bg-green-50 border border-green-200">
                  <CardHeader>
                    <CardTitle className="text-lg">NSSF Report</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-600 mb-4">
                      National Social Security Fund contribution details
                    </p>
                    <Button onClick={generateNSSFReport} className="w-full">
                      Download NSSF
                    </Button>
                  </CardContent>
                </Card>

                <Card className="bg-purple-50 border border-purple-200">
                  <CardHeader>
                    <CardTitle className="text-lg">NHIF Report</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-600 mb-4">
                      National Hospital Insurance Fund deduction details
                    </p>
                    <Button onClick={generateNHIFReport} className="w-full">
                      Download NHIF
                    </Button>
                  </CardContent>
                </Card>
              </div>

              <Card className="bg-yellow-50 border border-yellow-200">
                <CardHeader>
                  <CardTitle>Quarterly Reconciliation</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600 mb-4">
                    Ensure all deductions are submitted to respective authorities within deadlines
                  </p>
                  <div className="space-y-2 text-sm">
                    <p>• KRA PAYE: Submit by 9th of following month</p>
                    <p>• NSSF: Submit monthly</p>
                    <p>• NHIF: Submit monthly</p>
                  </div>
                </CardContent>
              </Card>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
