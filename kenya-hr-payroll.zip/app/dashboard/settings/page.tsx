'use client';

import { useEffect, useState } from 'react';
import { authService, AuthSession } from '@/lib/auth';
import { db, Company, User } from '@/lib/db-schema';
import { formatDate, generateId, getRoleDisplayName } from '@/lib/utils-hr';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

export default function SettingsPage() {
  const [session, setSession] = useState<AuthSession | null>(null);
  const [company, setCompany] = useState<Company | null>(null);
  const [users, setUsers] = useState<User[]>([]);
  const [isEditingCompany, setIsEditingCompany] = useState(false);
  const [isAddingUser, setIsAddingUser] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const [companyForm, setCompanyForm] = useState<Partial<Company>>({});
  const [userForm, setUserForm] = useState({
    email: '',
    firstName: '',
    lastName: '',
    role: 'manager' as const,
  });

  useEffect(() => {
    const token = localStorage.getItem('sessionToken');
    if (token) {
      const sess = authService.getSession(token);
      setSession(sess);
      if (sess) {
        const comp = db.getCompany(sess.companyId);
        if (comp) {
          setCompany(comp);
          setCompanyForm(comp);
        }

        const usrs = db.getUsersByCompany(sess.companyId);
        setUsers(usrs);
      }
    }
  }, []);

  const handleSaveCompany = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!company) return;

    try {
      const updated = db.updateCompany(company.id, companyForm);
      if (updated) {
        setCompany(updated);
        setIsEditingCompany(false);
        setSuccess('Company information updated');
        setTimeout(() => setSuccess(''), 3000);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update company');
    }
  };

  const handleAddUser = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!session) return;

    try {
      const newUser = authService.createUser(
        session.companyId,
        userForm.email,
        userForm.firstName,
        userForm.lastName,
        userForm.role
      );

      setUsers([...users, newUser]);
      setUserForm({
        email: '',
        firstName: '',
        lastName: '',
        role: 'manager',
      });
      setIsAddingUser(false);
      setSuccess('User added successfully. They have been sent an invitation.');
      setTimeout(() => setSuccess(''), 3000);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to add user');
    }
  };

  const handleResetPassword = (userId: string) => {
    const tempPassword = authService.resetUserPassword(userId);
    setSuccess(`Password reset. Temporary password: ${tempPassword}`);
    setTimeout(() => setSuccess(''), 5000);
  };

  if (!session) return null;

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Settings</h1>
        <p className="text-muted-foreground mt-1 text-sm">Manage your company profile and team members</p>
      </div>

      {error && (
        <div className="bg-destructive/10 border border-destructive text-destructive rounded-lg p-3 text-sm">
          {error}
        </div>
      )}

      {success && (
        <div className="bg-green-500/10 border border-green-500 text-green-600 rounded-lg p-3 text-sm">
          {success}
        </div>
      )}

      <Tabs defaultValue="company" className="w-full">
        <TabsList className="grid w-full grid-cols-2 bg-muted">
          <TabsTrigger value="company" className="text-sm">Company Profile</TabsTrigger>
          <TabsTrigger value="team" className="text-sm">Team Members</TabsTrigger>
        </TabsList>

        {/* Company Settings */}
        <TabsContent value="company">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>Company Information</CardTitle>
              {!isEditingCompany && (
                <Button size="sm" onClick={() => setIsEditingCompany(true)}>
                  Edit
                </Button>
              )}
            </CardHeader>
            <CardContent>
              {company ? (
                <form onSubmit={handleSaveCompany} className="space-y-6">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="name">Company Name</Label>
                      {isEditingCompany ? (
                        <Input
                          id="name"
                          value={companyForm.name || ''}
                          onChange={(e) => setCompanyForm({ ...companyForm, name: e.target.value })}
                        />
                      ) : (
                        <p className="py-2 text-gray-900">{company.name}</p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="reg">Registration Number</Label>
                      {isEditingCompany ? (
                        <Input
                          id="reg"
                          value={companyForm.registrationNumber || ''}
                          onChange={(e) => setCompanyForm({ ...companyForm, registrationNumber: e.target.value })}
                        />
                      ) : (
                        <p className="py-2 text-gray-900">{company.registrationNumber}</p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="taxPin">Tax PIN</Label>
                      {isEditingCompany ? (
                        <Input
                          id="taxPin"
                          value={companyForm.taxPin || ''}
                          onChange={(e) => setCompanyForm({ ...companyForm, taxPin: e.target.value })}
                        />
                      ) : (
                        <p className="py-2 text-gray-900">{company.taxPin}</p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="nssf">NSSF Number</Label>
                      {isEditingCompany ? (
                        <Input
                          id="nssf"
                          value={companyForm.nssf || ''}
                          onChange={(e) => setCompanyForm({ ...companyForm, nssf: e.target.value })}
                        />
                      ) : (
                        <p className="py-2 text-gray-900">{company.nssf}</p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="nhif">NHIF Number</Label>
                      {isEditingCompany ? (
                        <Input
                          id="nhif"
                          value={companyForm.nhif || ''}
                          onChange={(e) => setCompanyForm({ ...companyForm, nhif: e.target.value })}
                        />
                      ) : (
                        <p className="py-2 text-gray-900">{company.nhif}</p>
                      )}
                    </div>

                    <div className="col-span-2 space-y-2">
                      <Label htmlFor="address">Address</Label>
                      {isEditingCompany ? (
                        <Input
                          id="address"
                          value={companyForm.address || ''}
                          onChange={(e) => setCompanyForm({ ...companyForm, address: e.target.value })}
                        />
                      ) : (
                        <p className="py-2 text-gray-900">{company.address}</p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="phone">Phone</Label>
                      {isEditingCompany ? (
                        <Input
                          id="phone"
                          value={companyForm.phone || ''}
                          onChange={(e) => setCompanyForm({ ...companyForm, phone: e.target.value })}
                        />
                      ) : (
                        <p className="py-2 text-gray-900">{company.phone}</p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="email">Email</Label>
                      {isEditingCompany ? (
                        <Input
                          id="email"
                          type="email"
                          value={companyForm.email || ''}
                          onChange={(e) => setCompanyForm({ ...companyForm, email: e.target.value })}
                        />
                      ) : (
                        <p className="py-2 text-gray-900">{company.email}</p>
                      )}
                    </div>
                  </div>

                  {isEditingCompany && (
                    <div className="flex gap-3 justify-end pt-4">
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => {
                          setIsEditingCompany(false);
                          setCompanyForm(company);
                        }}
                      >
                        Cancel
                      </Button>
                      <Button type="submit">Save Changes</Button>
                    </div>
                  )}
                </form>
              ) : (
                <p className="text-gray-600">Loading company information...</p>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Team Members */}
        <TabsContent value="users">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>Team Members</CardTitle>
              <Dialog open={isAddingUser} onOpenChange={setIsAddingUser}>
                <DialogTrigger asChild>
                  <Button size="sm">Add Team Member</Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Add Team Member</DialogTitle>
                    <DialogDescription>Invite a new user to your organization</DialogDescription>
                  </DialogHeader>

                  <form onSubmit={handleAddUser} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="firstName">First Name</Label>
                      <Input
                        id="firstName"
                        value={userForm.firstName}
                        onChange={(e) => setUserForm({ ...userForm, firstName: e.target.value })}
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="lastName">Last Name</Label>
                      <Input
                        id="lastName"
                        value={userForm.lastName}
                        onChange={(e) => setUserForm({ ...userForm, lastName: e.target.value })}
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="email">Email</Label>
                      <Input
                        id="email"
                        type="email"
                        value={userForm.email}
                        onChange={(e) => setUserForm({ ...userForm, email: e.target.value })}
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="role">Role</Label>
                      <select
                        id="role"
                        value={userForm.role}
                        onChange={(e) => setUserForm({ ...userForm, role: e.target.value as any })}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md"
                      >
                        <option value="employee">Employee</option>
                        <option value="manager">HR Manager</option>
                        <option value="admin">Administrator</option>
                      </select>
                    </div>

                    <div className="flex gap-3 justify-end">
                      <Button type="button" variant="outline" onClick={() => setIsAddingUser(false)}>
                        Cancel
                      </Button>
                      <Button type="submit">Add Member</Button>
                    </div>
                  </form>
                </DialogContent>
              </Dialog>
            </CardHeader>
            <CardContent>
              {users.length === 0 ? (
                <p className="text-center py-12 text-gray-600">No team members added yet</p>
              ) : (
                <div className="space-y-3">
                  {users.map((user) => (
                    <div key={user.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                      <div>
                        <p className="font-medium text-gray-900">
                          {user.firstName} {user.lastName}
                        </p>
                        <div className="flex gap-4 text-sm text-gray-600 mt-1">
                          <span>{user.email}</span>
                          <span className="px-2 py-1 bg-gray-100 rounded text-xs">
                            {getRoleDisplayName(user.role)}
                          </span>
                        </div>
                      </div>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleResetPassword(user.id)}
                      >
                        Reset Password
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Profile */}
        <TabsContent value="profile">
          <Card>
            <CardHeader>
              <CardTitle>My Profile</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Name</Label>
                    <p className="py-2 text-gray-900">{session.userName}</p>
                  </div>

                  <div className="space-y-2">
                    <Label>Email</Label>
                    <p className="py-2 text-gray-900">{session.userEmail}</p>
                  </div>

                  <div className="space-y-2">
                    <Label>Role</Label>
                    <p className="py-2 text-gray-900">{getRoleDisplayName(session.userRole)}</p>
                  </div>

                  <div className="space-y-2">
                    <Label>Company</Label>
                    <p className="py-2 text-gray-900">{session.companyName}</p>
                  </div>
                </div>

                <div className="pt-4 border-t border-gray-200">
                  <Button variant="outline">Change Password</Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
