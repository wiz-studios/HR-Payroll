'use client';

import { useEffect, useState } from 'react';
import { authService, AuthSession } from '@/lib/auth';
import { db, ComplianceRecord } from '@/lib/db-schema';
import { generateId, getMonthName, formatDate, getStatusDisplayName, getStatusColor } from '@/lib/utils-hr';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

interface ComplianceDeadline {
  authority: string;
  frequency: string;
  deadline: string;
  description: string;
}

const COMPLIANCE_DEADLINES: ComplianceDeadline[] = [
  {
    authority: 'KRA (PAYE)',
    frequency: 'Monthly',
    deadline: '9th of following month',
    description: 'Personal Income Tax (PAYE) remittance to KRA',
  },
  {
    authority: 'NSSF',
    frequency: 'Monthly',
    deadline: 'End of following month',
    description: 'National Social Security Fund contributions',
  },
  {
    authority: 'NHIF',
    frequency: 'Monthly',
    deadline: 'End of following month',
    description: 'National Hospital Insurance Fund premiums',
  },
  {
    authority: 'KRA P9 Return',
    frequency: 'Quarterly',
    deadline: 'By 14th of month following quarter',
    description: 'Personal income tax return filing',
  },
  {
    authority: 'NSSF Annual Report',
    frequency: 'Annual',
    deadline: '31st January',
    description: 'Annual NSSF returns and reconciliation',
  },
  {
    authority: 'NHIF Annual Report',
    frequency: 'Annual',
    deadline: '31st January',
    description: 'Annual NHIF declarations',
  },
];

export default function CompliancePage() {
  const [session, setSession] = useState<AuthSession | null>(null);
  const [records, setRecords] = useState<ComplianceRecord[]>([]);
  const [isCreating, setIsCreating] = useState(false);
  const [selectedAuthority, setSelectedAuthority] = useState('KRA (PAYE)');
  const [selectedPeriod, setSelectedPeriod] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  useEffect(() => {
    const token = localStorage.getItem('sessionToken');
    if (token) {
      const sess = authService.getSession(token);
      setSession(sess);
      if (sess) {
        const recs = db.getComplianceRecordsByCompany(sess.companyId);
        setRecords(recs.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime()));
      }
    }
  }, []);

  const handleCreateRecord = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!session) return;

    try {
      const recordType = selectedAuthority.toLowerCase().replace(/\s+/g, '_');

      const record: ComplianceRecord = {
        id: generateId('compliance'),
        companyId: session.companyId,
        recordType: recordType as any,
        period: selectedPeriod,
        status: 'pending',
        details: {
          authority: selectedAuthority,
          submissionNotes: '',
        },
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      db.createComplianceRecord(record);
      setRecords([record, ...records]);
      setSelectedPeriod('');
      setIsCreating(false);
      setSuccess('Compliance record created');
      setTimeout(() => setSuccess(''), 3000);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to create record');
    }
  };

  const handleUpdateStatus = (recordId: string, newStatus: ComplianceRecord['status']) => {
    const record = db.getComplianceRecordsByCompany(session?.companyId || '').find(r => r.id === recordId);
    if (record) {
      const updated = {
        ...record,
        status: newStatus,
        submissionDate: newStatus === 'submitted' ? new Date() : record.submissionDate,
        updatedAt: new Date(),
      };
      // Update in database (simplified)
      const index = records.findIndex(r => r.id === recordId);
      const newRecords = [...records];
      newRecords[index] = updated;
      setRecords(newRecords);
      setSuccess('Status updated');
      setTimeout(() => setSuccess(''), 3000);
    }
  };

  if (!session) return null;

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Compliance Management</h1>
        <p className="text-muted-foreground mt-1 text-sm">Track and manage statutory compliance deadlines and submissions</p>
      </div>
      </div>

      {error && (
        <Alert variant="destructive">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {success && (
        <Alert className="bg-green-50 text-green-800 border-green-200">
          <AlertDescription>{success}</AlertDescription>
        </Alert>
      )}

      <Tabs defaultValue="deadlines" className="w-full">
        <TabsList>
          <TabsTrigger value="deadlines">Compliance Deadlines</TabsTrigger>
          <TabsTrigger value="records">Submission Records</TabsTrigger>
          <TabsTrigger value="checklist">Compliance Checklist</TabsTrigger>
        </TabsList>

        {/* Deadlines */}
        <TabsContent value="deadlines" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Regulatory Deadlines for Kenya</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {COMPLIANCE_DEADLINES.map((deadline, index) => (
                  <div key={index} className="flex items-start gap-4 p-4 border border-gray-200 rounded-lg hover:bg-gray-50">
                    <div className="flex-1">
                      <p className="font-semibold text-gray-900">{deadline.authority}</p>
                      <p className="text-sm text-gray-600 mt-1">{deadline.description}</p>
                      <div className="flex gap-4 mt-2 text-sm text-gray-600">
                        <span>Frequency: <strong>{deadline.frequency}</strong></span>
                        <span>Deadline: <strong>{deadline.deadline}</strong></span>
                      </div>
                    </div>
                    <Dialog open={isCreating && selectedAuthority === deadline.authority} onOpenChange={setIsCreating}>
                      <DialogTrigger asChild>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => setSelectedAuthority(deadline.authority)}
                        >
                          Log Submission
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Log {deadline.authority} Submission</DialogTitle>
                          <DialogDescription>
                            Record when you submit {deadline.authority} compliance
                          </DialogDescription>
                        </DialogHeader>
                        <form onSubmit={handleCreateRecord} className="space-y-4">
                          <div className="space-y-2">
                            <Label htmlFor="period">Period (YYYY-MM or YYYY-Q#)</Label>
                            <Input
                              id="period"
                              placeholder="2024-01 or 2024-Q1"
                              value={selectedPeriod}
                              onChange={(e) => setSelectedPeriod(e.target.value)}
                              required
                            />
                          </div>
                          <div className="flex gap-3 justify-end">
                            <Button type="button" variant="outline" onClick={() => setIsCreating(false)}>
                              Cancel
                            </Button>
                            <Button type="submit">Log Submission</Button>
                          </div>
                        </form>
                      </DialogContent>
                    </Dialog>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Records */}
        <TabsContent value="records" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Submission History</CardTitle>
            </CardHeader>
            <CardContent>
              {records.length === 0 ? (
                <p className="text-center py-12 text-gray-600">No submission records yet</p>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-gray-200">
                        <th className="text-left py-3 px-4 font-medium text-gray-900">Authority</th>
                        <th className="text-left py-3 px-4 font-medium text-gray-900">Period</th>
                        <th className="text-left py-3 px-4 font-medium text-gray-900">Status</th>
                        <th className="text-left py-3 px-4 font-medium text-gray-900">Submitted</th>
                        <th className="text-left py-3 px-4 font-medium text-gray-900">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {records.map((record) => (
                        <tr key={record.id} className="border-b border-gray-100 hover:bg-gray-50">
                          <td className="py-3 px-4 capitalize">{record.details.authority}</td>
                          <td className="py-3 px-4">{record.period}</td>
                          <td className="py-3 px-4">
                            <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(record.status)}`}>
                              {getStatusDisplayName(record.status)}
                            </span>
                          </td>
                          <td className="py-3 px-4">
                            {record.submissionDate ? formatDate(record.submissionDate) : '—'}
                          </td>
                          <td className="py-3 px-4">
                            {record.status === 'pending' && (
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleUpdateStatus(record.id, 'submitted')}
                              >
                                Mark Submitted
                              </Button>
                            )}
                            {record.status === 'submitted' && (
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleUpdateStatus(record.id, 'accepted')}
                              >
                                Mark Accepted
                              </Button>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Checklist */}
        <TabsContent value="checklist" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Monthly Compliance Checklist</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center gap-3 p-3 border border-gray-200 rounded hover:bg-gray-50">
                  <input type="checkbox" id="payroll" className="w-4 h-4" />
                  <label htmlFor="payroll" className="flex-1 cursor-pointer">
                    <p className="font-medium">Run payroll calculations</p>
                    <p className="text-sm text-gray-600">Process employee salaries and deductions</p>
                  </label>
                </div>

                <div className="flex items-center gap-3 p-3 border border-gray-200 rounded hover:bg-gray-50">
                  <input type="checkbox" id="kra" className="w-4 h-4" />
                  <label htmlFor="kra" className="flex-1 cursor-pointer">
                    <p className="font-medium">Submit PAYE to KRA</p>
                    <p className="text-sm text-gray-600">By 9th of following month</p>
                  </label>
                </div>

                <div className="flex items-center gap-3 p-3 border border-gray-200 rounded hover:bg-gray-50">
                  <input type="checkbox" id="nssf" className="w-4 h-4" />
                  <label htmlFor="nssf" className="flex-1 cursor-pointer">
                    <p className="font-medium">Submit NSSF contributions</p>
                    <p className="text-sm text-gray-600">End of month or as scheduled</p>
                  </label>
                </div>

                <div className="flex items-center gap-3 p-3 border border-gray-200 rounded hover:bg-gray-50">
                  <input type="checkbox" id="nhif" className="w-4 h-4" />
                  <label htmlFor="nhif" className="flex-1 cursor-pointer">
                    <p className="font-medium">Submit NHIF premiums</p>
                    <p className="text-sm text-gray-600">End of month or as scheduled</p>
                  </label>
                </div>

                <div className="flex items-center gap-3 p-3 border border-gray-200 rounded hover:bg-gray-50">
                  <input type="checkbox" id="payslips" className="w-4 h-4" />
                  <label htmlFor="payslips" className="flex-1 cursor-pointer">
                    <p className="font-medium">Distribute payslips to employees</p>
                    <p className="text-sm text-gray-600">Before or on payday</p>
                  </label>
                </div>

                <div className="flex items-center gap-3 p-3 border border-gray-200 rounded hover:bg-gray-50">
                  <input type="checkbox" id="reconcile" className="w-4 h-4" />
                  <label htmlFor="reconcile" className="flex-1 cursor-pointer">
                    <p className="font-medium">Reconcile bank transfers</p>
                    <p className="text-sm text-gray-600">Verify all payments processed</p>
                  </label>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-blue-50 border-blue-200">
            <CardHeader>
              <CardTitle>Quarterly Tasks</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-start gap-3">
                  <span className="text-blue-600 font-bold mt-1">Q</span>
                  <div>
                    <p className="font-medium">File P9 Returns with KRA</p>
                    <p className="text-sm text-gray-600">By 14th of month following quarter</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <span className="text-blue-600 font-bold mt-1">Q</span>
                  <div>
                    <p className="font-medium">Reconcile tax withholdings</p>
                    <p className="text-sm text-gray-600">Ensure all PAYE remitted correctly</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-purple-50 border-purple-200">
            <CardHeader>
              <CardTitle>Annual Tasks</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-start gap-3">
                  <span className="text-purple-600 font-bold mt-1">A</span>
                  <div>
                    <p className="font-medium">File annual NSSF returns</p>
                    <p className="text-sm text-gray-600">By 31st January of following year</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <span className="text-purple-600 font-bold mt-1">A</span>
                  <div>
                    <p className="font-medium">File annual NHIF declarations</p>
                    <p className="text-sm text-gray-600">By 31st January of following year</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <span className="text-purple-600 font-bold mt-1">A</span>
                  <div>
                    <p className="font-medium">Prepare annual tax reconciliation</p>
                    <p className="text-sm text-gray-600">Complete before year-end audit</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
