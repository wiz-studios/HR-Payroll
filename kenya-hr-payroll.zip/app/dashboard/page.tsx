'use client';

import { useEffect, useState } from 'react';
import { authService, AuthSession } from '@/lib/auth';
import { db } from '@/lib/db-schema';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { formatCurrency } from '@/lib/utils-hr';

export default function DashboardPage() {
  const [session, setSession] = useState<AuthSession | null>(null);
  const [stats, setStats] = useState({
    totalEmployees: 0,
    activePayrolls: 0,
    pendingApprovals: 0,
    totalGrossSalaries: 0,
  });

  useEffect(() => {
    const token = localStorage.getItem('sessionToken');
    if (token) {
      const sess = authService.getSession(token);
      setSession(sess);

      // Calculate dashboard stats
      if (sess) {
        const employees = db.getEmployeesByCompany(sess.companyId);
        const payrolls = db.getPayrollsByCompany(sess.companyId);
        const activePayroll = payrolls.filter(p => p.status === 'pending_approval' || p.status === 'draft');
        const pending = payrolls.filter(p => p.status === 'pending_approval');

        let totalGross = 0;
        const payrollDetails = activePayroll.flatMap(p => db.getPayrollDetailsByPayroll(p.id));
        payrollDetails.forEach(d => {
          totalGross += d.grossPay;
        });

        setStats({
          totalEmployees: employees.length,
          activePayrolls: activePayroll.length,
          pendingApprovals: pending.length,
          totalGrossSalaries: totalGross,
        });
      }
    }
  }, []);

  if (!session) return null;

  const statCards = [
    {
      title: 'Total Employees',
      value: stats.totalEmployees,
      icon: '👥',
      color: 'bg-blue-100 text-blue-700',
    },
    {
      title: 'Active Payrolls',
      value: stats.activePayrolls,
      icon: '📊',
      color: 'bg-green-100 text-green-700',
    },
    {
      title: 'Pending Approvals',
      value: stats.pendingApprovals,
      icon: '⏳',
      color: 'bg-yellow-100 text-yellow-700',
    },
    {
      title: 'Total Gross Salaries',
      value: formatCurrency(stats.totalGrossSalaries),
      icon: '💰',
      color: 'bg-purple-100 text-purple-700',
    },
  ];

  return (
    <div className="space-y-8">
      {/* Welcome Section */}
      <div>
        <h2 className="text-3xl font-bold text-foreground">
          Welcome back, {session.userName}!
        </h2>
        <p className="text-muted-foreground mt-1 text-sm">
          {session.companyName} • {new Date().toLocaleDateString('en-KE', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric',
          })}
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
        {statCards.map((stat, index) => (
          <Card key={index} className="border-border hover:shadow-md transition-shadow">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                  {stat.title}
                </CardTitle>
                <div className="text-2xl">{stat.icon}</div>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-foreground">{stat.value}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        <Card className="lg:col-span-2 border-border">
          <CardHeader>
            <CardTitle className="text-lg">Quick Actions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <a
                href="/dashboard/employees"
                className="p-5 border border-border rounded-lg hover:bg-accent/5 transition-colors group"
              >
                <p className="font-semibold text-foreground group-hover:text-primary transition">👥 Manage Employees</p>
                <p className="text-xs text-muted-foreground mt-2">Add, edit, or view records</p>
              </a>
              <a
                href="/dashboard/payroll"
                className="p-5 border border-border rounded-lg hover:bg-accent/5 transition-colors group"
              >
                <p className="font-semibold text-foreground group-hover:text-accent transition">💰 Run Payroll</p>
                <p className="text-xs text-muted-foreground mt-2">Create and process payroll</p>
              </a>
              <a
                href="/dashboard/reports"
                className="p-5 border border-border rounded-lg hover:bg-accent/5 transition-colors group"
              >
                <p className="font-semibold text-foreground group-hover:text-primary transition">📈 View Reports</p>
                <p className="text-xs text-muted-foreground mt-2">Compliance & financial reports</p>
              </a>
            </div>
          </CardContent>
        </Card>

        {/* System Status */}
        <Card className="border-border">
          <CardHeader>
            <CardTitle className="text-lg">System Status</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-start gap-3">
              <div className="mt-1 w-2 h-2 rounded-full bg-green-500 flex-shrink-0"></div>
              <div>
                <p className="text-sm font-medium text-foreground">Database</p>
                <p className="text-xs text-muted-foreground">Active</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="mt-1 w-2 h-2 rounded-full bg-green-500 flex-shrink-0"></div>
              <div>
                <p className="text-sm font-medium text-foreground">All Systems</p>
                <p className="text-xs text-muted-foreground">Operational</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="mt-1 w-2 h-2 rounded-full bg-green-500 flex-shrink-0"></div>
              <div>
                <p className="text-sm font-medium text-foreground">Data Backup</p>
                <p className="text-xs text-muted-foreground">Last 1h ago</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
