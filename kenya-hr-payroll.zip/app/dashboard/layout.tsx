'use client';

import { ReactNode, useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter, usePathname } from 'next/navigation';
import { authService, AuthSession } from '@/lib/auth';
import { Button } from '@/components/ui/button';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from '@/components/ui/dropdown-menu';

interface DashboardLayoutProps {
  children: ReactNode;
}

export default function DashboardLayout({ children }: DashboardLayoutProps) {
  const router = useRouter();
  const pathname = usePathname();
  const [session, setSession] = useState<AuthSession | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [sidebarOpen, setSidebarOpen] = useState(true);

  useEffect(() => {
    // Get session from localStorage
    const token = localStorage.getItem('sessionToken');
    if (!token) {
      router.push('/');
      return;
    }

    const sess = authService.getSession(token);
    if (!sess) {
      localStorage.removeItem('sessionToken');
      router.push('/');
      return;
    }

    setSession(sess);
    setIsLoading(false);
  }, [router]);

  const handleLogout = () => {
    const token = localStorage.getItem('sessionToken');
    if (token) {
      authService.logout(token);
      localStorage.removeItem('sessionToken');
    }
    router.push('/');
  };

  const isActive = (path: string) => pathname === path || pathname.startsWith(path + '/');

  const navItems = [
    { label: 'Dashboard', path: '/dashboard', icon: '📊' },
    { label: 'Employees', path: '/dashboard/employees', icon: '👥', roles: ['admin', 'manager'] },
    { label: 'Leave Management', path: '/dashboard/leaves', icon: '📅', roles: ['admin', 'manager'] },
    { label: 'Payroll', path: '/dashboard/payroll', icon: '💰', roles: ['admin', 'manager'] },
    { label: 'Reports', path: '/dashboard/reports', icon: '📈', roles: ['admin', 'manager'] },
    { label: 'Compliance', path: '/dashboard/compliance', icon: '✅', roles: ['admin'] },
    { label: 'Settings', path: '/dashboard/settings', icon: '⚙️', roles: ['admin'] },
  ];

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-muted-foreground">Loading...</div>
      </div>
    );
  }

  if (!session) {
    return null;
  }

  const visibleNavItems = navItems.filter(
    item => !item.roles || item.roles.includes(session.userRole)
  );

  return (
    <div className="min-h-screen bg-background flex">
      {/* Sidebar */}
      <aside
        className={`${
          sidebarOpen ? 'w-64' : 'w-20'
        } bg-sidebar text-sidebar-foreground transition-all duration-300 flex flex-col border-r border-sidebar-border`}
      >
        {/* Logo */}
        <div className="p-6 border-b border-sidebar-border">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-primary flex items-center justify-center text-primary-foreground font-bold text-sm">
              PK
            </div>
            {sidebarOpen && <span className="font-bold text-base">PayrollKE</span>}
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 px-3 py-6 space-y-2">
          {visibleNavItems.map(item => (
            <Link
              key={item.path}
              href={item.path}
              className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                isActive(item.path)
                  ? 'bg-sidebar-primary text-sidebar-primary-foreground'
                  : 'text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground'
              }`}
            >
              <span className="text-xl w-6 flex-shrink-0">{item.icon}</span>
              {sidebarOpen && <span className="text-sm font-medium">{item.label}</span>}
            </Link>
          ))}
        </nav>

        {/* Toggle Button */}
        <div className="px-3 py-4 border-t border-sidebar-border">
          <Button
            variant="ghost"
            size="sm"
            className="w-full text-sidebar-foreground/70 hover:text-sidebar-foreground hover:bg-sidebar-accent"
            onClick={() => setSidebarOpen(!sidebarOpen)}
          >
            {sidebarOpen ? '←' : '→'}
          </Button>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col bg-background">
        {/* Header */}
        <header className="bg-card border-b border-border shadow-sm sticky top-0 z-10">
          <div className="px-8 py-5 flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">{session.companyName}</p>
              <h1 className="text-2xl font-bold text-foreground mt-1">Dashboard</h1>
            </div>

            <div className="flex items-center gap-4">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="sm" className="h-10 w-10 rounded-full">
                    <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center text-primary font-bold text-sm">
                      {session.userName.charAt(0).toUpperCase()}
                    </div>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <div className="px-4 py-3 border-b border-border">
                    <p className="text-sm font-semibold text-foreground">{session.userName}</p>
                    <p className="text-xs text-muted-foreground mt-1">{session.userEmail}</p>
                    <p className="text-xs text-muted-foreground/60 mt-1 capitalize">Role: {session.userRole}</p>
                  </div>
                  <DropdownMenuItem className="cursor-pointer">
                    <Link href="/dashboard/settings" className="w-full text-sm">
                      Settings
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleLogout} className="cursor-pointer text-destructive text-sm">
                    Logout
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 overflow-auto">
          <div className="p-8">{children}</div>
        </main>
      </div>
    </div>
  );
}
