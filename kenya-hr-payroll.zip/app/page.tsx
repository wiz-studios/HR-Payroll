'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { authService } from '@/lib/auth';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    try {
      const { sessionToken } = authService.login({
        email,
        password,
      });

      // Store session token
      localStorage.setItem('sessionToken', sessionToken);

      // Redirect to dashboard
      router.push('/dashboard');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Login failed');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-10">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-xl bg-primary text-primary-foreground mb-6 shadow-lg">
            <span className="text-2xl font-bold">PK</span>
          </div>
          <h1 className="text-4xl font-bold text-foreground">PayrollKE</h1>
          <p className="text-muted-foreground mt-2 text-sm">Kenya HR & Payroll Management System</p>
        </div>

        {/* Login Card */}
        <Card className="shadow-xl border-border">
          <CardHeader className="pb-5">
            <CardTitle className="text-2xl">Sign In</CardTitle>
            <CardDescription className="text-sm">Access your payroll and HR management system</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-5">
              {error && (
                <Alert variant="destructive">
                  <AlertDescription className="text-sm">{error}</AlertDescription>
                </Alert>
              )}

              <div className="space-y-2">
                <Label htmlFor="email" className="text-sm font-medium">Email Address</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="you@company.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="border-border bg-input"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="password" className="text-sm font-medium">Password</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="border-border bg-input"
                  required
                />
              </div>

              <Button 
                type="submit" 
                className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-medium"
                disabled={isLoading}
              >
                {isLoading ? 'Signing in...' : 'Sign In'}
              </Button>
            </form>

            <div className="mt-6 pt-6 border-t border-border">
              <p className="text-center text-sm text-muted-foreground">
                New to PayrollKE?{' '}
                <Link href="/register" className="text-primary hover:text-primary/90 font-semibold">
                  Register your company
                </Link>
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Demo Credentials */}
        <div className="mt-8 p-5 bg-card rounded-lg border border-border text-sm">
          <p className="font-semibold text-foreground mb-3">Demo Credentials:</p>
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="text-muted-foreground">Email:</span>
              <code className="bg-input px-2.5 py-1.5 rounded text-xs font-mono text-foreground">admin@techcorp.com</code>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-muted-foreground">Password:</span>
              <code className="bg-input px-2.5 py-1.5 rounded text-xs font-mono text-foreground">AdminPass123</code>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
